
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",4645,function(sym,e){});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'SYMBOLE_FILLE'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",995,function(sym,e){sym.play(0);});
//Edge binding end
})("SYMBOLE_FILLE");
//Edge symbol end:'SYMBOLE_FILLE'

//=========================================================

//Edge symbol: 'SYMBOLE_GARCON'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",995,function(sym,e){sym.play(0);});
//Edge binding end
})("SYMBOLE_GARCON");
//Edge symbol end:'SYMBOLE_GARCON'
})(jQuery,AdobeEdge,"EDGE-20745423");